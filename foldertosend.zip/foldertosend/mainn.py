from openpyxl import load_workbook

import pandas as pd

import xlwings as xw

LBSR_con=r"outputConsolidated\outPut_Consolidated.xlsx"


file="SDMX Conversion Template.xlsm"
sheetslist = ["Claims_Total","Claims_LandD","Claims_DSec","Claims_Others","Lbt_Total","Lbt_LandD","Lbt_Dsec","Lbt_Others","Lbt_Dsec_Mat"]

ranges=[
    ["C15:DR249","C14"],
    ["C261:DR265","C262"],
    ["C277:DR281","C278"],
    ["C293:DR297","C294"]
]
def load_workbook_range(range_string, ws):
    data_rows = []
    for row in ws[range_string]:
        data_rows.append([cell.value for cell in row])

    return pd.DataFrame(data_rows)

book = load_workbook(LBSR_con)
wb = xw.Book(file)

for sheetname in sheetslist:
    sheet=book[sheetname]



    df1 =load_workbook_range(ranges[0][0],sheet)
    df2 =load_workbook_range(ranges[1][0],sheet)
    df3 =load_workbook_range(ranges[2][0],sheet)
    df4 =load_workbook_range(ranges[3][0],sheet)


    sheet_wing = wb.sheets[sheetname]
    print(sheet_wing)
    sheet_wing[ranges[0][1]].options(pd.DataFrame, header=0, index=False, expand='table').value = df1
    sheet_wing[ranges[1][1]].options(pd.DataFrame, header=0, index=False, expand='table').value = df2
    sheet_wing[ranges[2][1]].options(pd.DataFrame, header=0, index=False, expand='table').value = df3
    sheet_wing[ranges[3][1]].options(pd.DataFrame, header=0, index=False, expand='table').value = df4



macro1=wb.macro("GESMES_Routines.Main")
macro1()



wb.save('out.xlsm')
app = xw.apps.active
#wb.close()
wb.app.quit()
