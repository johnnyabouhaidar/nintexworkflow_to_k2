from xlutils.copy import copy # http://pypi.python.org/pypi/xlutils
from xlrd import open_workbook # http://pypi.python.org/pypi/xlrd
from xlwt import easyxf # http://pypi.python.org/pypi/xlwt

file_path = 'newnew.xls'
rb = open_workbook('SDMX Conversion Template.xls',formatting_info=True)
r_sheet = rb.sheet_by_name('Claims_LandD') # read only copy to introspect the file
wb = copy(rb) # a writable copy (I can't read values out of this, only write to it)
w_sheet = wb.get_sheet(2) # the sheet to write to within the writable copy
w_sheet.write(13, 2, 'Value')
wb.save(file_path)